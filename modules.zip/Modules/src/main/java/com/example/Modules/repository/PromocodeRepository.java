package com.example.Modules.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Modules.model.PromoDTO;



public interface PromocodeRepository extends JpaRepository<PromoDTO, String> {

}
