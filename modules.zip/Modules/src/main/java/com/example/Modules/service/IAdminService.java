package com.example.Modules.service;

import java.util.List;

import com.example.Modules.model.PromoDTO;

public interface IAdminService {

	public void createpromocode(PromoDTO promoCode);
    public List<PromoDTO> getpromocodes();
    public List<PromoDTO> sendpromocodes();
   
	
}
