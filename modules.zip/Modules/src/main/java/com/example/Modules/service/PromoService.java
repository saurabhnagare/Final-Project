package com.example.Modules.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Modules.model.CustomerDTO;
import com.example.Modules.model.PromoDTO;
import com.example.Modules.repository.PromocodeRepository;

@Service("promoService")
public class PromoService implements IPromoService{


	
	@Autowired
	private PromocodeRepository promocodeRepository;
	
	@Override
/*	public int getDiscount(int promoId) {
		Promos p= (Promos) promoDao.findById(promoId).get();

		
		return p.getDiscount();
	}*/
	 
	
	public PromoDTO createPromo(PromoDTO promo) {
		return promocodeRepository.save(promo);	
	}

	@Override
	public List<PromoDTO> getAllPromos() {
		return promocodeRepository.findAll();
	}

	/*

	@Override
	public void sendEmailToCustomer(Email email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CustomerDTO> getCustomerList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sendEmail(Email mail) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Email> getEmails(String emailId) {
		// TODO Auto-generated method stub
		return null;
	}

*/	
}
