package com.example.Modules.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="PROMO")
public class PromoDTO {
	
	
	@Id
	@Column(name="PROMOCODE")
	private String promoCode;
	
	@Column(name="DISCOUNTOFFERED")
	private int discountOffered;
	
	@Column(name="PROMOVALIDITY")
	private Date promoValidity;
	
	public PromoDTO()
	{
		
	}
	
	public PromoDTO(String promoCode, int discountOffered, Date promoValidity)
	{
		super();
		this.promoCode = promoCode;
		this.discountOffered = discountOffered;
		this.promoValidity = promoValidity;
	}
	
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getDiscountOffered() {
		return discountOffered;
	}
	public void setDiscountOdffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}
	public Date getPromoValidity() {
		return promoValidity;
	}
	public void setPromoValidity(Date promoValidity) {
		this.promoValidity = promoValidity;
	}
	
	
}
