package com.example.Modules.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



import com.example.Modules.model.PromoDTO;
import com.example.Modules.repository.AdminRepository;

import com.example.Modules.service.IPromoService;



@RestController
@RequestMapping("api/v1/manage_attractions")
public class AdminController {
	
	
	
	
	

	
	@Autowired
	IPromoService promoService;
	
	
	


	
	

	

//	************************Inventory(Products)**********************************************
	


@RequestMapping(value = "/create_promocode", method = RequestMethod.POST)
	public PromoDTO createPromocode(@RequestBody PromoDTO promo){
	return promoService.createPromo(promo);		
	}


@RequestMapping(value = "/view_promocode", method = RequestMethod.GET)
public List<PromoDTO> viewAllPromos()
{
	return promoService.getAllPromos();
}



}
