package com.example.Modules.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Modules.model.PromoDTO;
import com.example.Modules.repository.AdminRepository;


public class AdminServiceImpl implements IAdminService {

	@Autowired
	private AdminRepository adminRepository;
	
	PromoDTO promo = new PromoDTO();

	@Override
	public void createpromocode(PromoDTO promoCode) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<PromoDTO> getpromocodes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PromoDTO> sendpromocodes() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*@Override
	public void createpromocode(PromoDTO promoCode) {
		// TODO Auto-generated method stub
		adminRepository.save(promoCode);
	//	promo.setPromoCode(promoCode);
		
	}

	@Override
	public List<PromoDTO> getpromocodes() {
		// TODO Auto-generated method stub
		return adminRepository.findall();
	}

	@Override
	public List<PromoDTO> sendpromocodes() {
		// TODO Auto-generated method stub
		return null;
	}*/

}
