package com.example.Modules.service;

import java.util.List;


import com.example.Modules.model.CustomerDTO;
import com.example.Modules.model.PromoDTO;

public interface IPromoService {

	public  PromoDTO  createPromo(PromoDTO promo);
	
	public List<PromoDTO> getAllPromos();
	
	/*public void sendEmailToCustomer(Email email);

	public List<CustomerDTO> getCustomerList();

	public void sendEmail(Email mail);

	List<Email> getEmails(String emailId);
*/}
