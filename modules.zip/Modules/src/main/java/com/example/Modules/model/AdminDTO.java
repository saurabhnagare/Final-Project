package com.example.Modules.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name="ADMINDETAIL")
public class AdminDTO {

	@Id
	@Column(name="ADMINID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int adminId;
	
	@Column(name="ADMINNAME")
	private String adminName;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="MOBILENO")
	private String mobileNo;
	
	@OneToMany(targetEntity=PromoDTO.class,  mappedBy = "ADMINDETAIL", fetch = FetchType.LAZY)
	private List<PromoDTO> promos;
	
	@OneToMany(targetEntity=ReturnRequestDTO.class, mappedBy = "ADMINDETAIL", fetch = FetchType.LAZY)
	private List<ReturnRequestDTO> returnRequests;
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	public List<PromoDTO> getPromos() {
		return promos;
	}
	public void setPromos(List<PromoDTO> promos) {
		this.promos = promos;
	}
	public List<ReturnRequestDTO> getReturnRequests() {
		return returnRequests;
	}
	public void setReturnRequests(List<ReturnRequestDTO> returnRequests) {
		this.returnRequests = returnRequests;
	}
	
	
	
	
}
