package com.example.Modules.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="CART")
public class CartDTO{
	
	
	@Id
	@Column(name="PROMOCODE")
	private String promoCode;
	
	@Column(name=" PRODUCTQUANTITY")
	private int productQuantity;
	
	@Column(name=" PRODUCTPRICE")
	private int productPrice;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<ProductDTO> product;

	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public List<ProductDTO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDTO> product) {
		this.product = product;
	}
	
	
	}
