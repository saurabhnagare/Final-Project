package com.example.Modules.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="OFFER")
public class OfferDTO {
	
	
	@Id
	@Column(name="OFFERDESCRIPTION")
	private String offerDescription;
	
	@Column(name="OFFERSTARTDATE")
	private Date offerStartDate;
	
	@Column(name="OFFERENDDATE")
	private Date offerEndDate;
	
	@Column(name="DISCOUNTOFFERED")
	private int discountOffered;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private MerchantDTO merchant;
	
	@OneToOne(fetch = FetchType.LAZY)
	private ProductDTO product;
	
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	public Date getOfferStartDate() {
		return offerStartDate;
	}
	public void setOfferStartDate(Date offerStartDate) {
		this.offerStartDate = offerStartDate;
	}
	public Date getOfferEndDate() {
		return offerEndDate;
	}
	public void setOfferEndDate(Date offerEndDate) {
		this.offerEndDate = offerEndDate;
	}
	public int getDiscountOffered() {
		return discountOffered;
	}
	public void setDiscountOffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}
	public MerchantDTO getMerchant() {
		return merchant;
	}
	public void setMerchant(MerchantDTO merchant) {
		this.merchant = merchant;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	
	
	
}
