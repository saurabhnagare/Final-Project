package com.capstore.admin.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="promo")
public class PromoDTO {

	@Id
	@Column(name="promocode")
	private String promoCode;
	
	@Column(name="discount_offered")
	private int discountOffered;
	
	@Column(name="promo_validity")
	private Date promoValidity;
	
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getDiscountOffered() {
		return discountOffered;
	}
	public void setDiscountOdffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}
	public Date getPromoValidity() {
		return promoValidity;
	}
	public void setPromoValidity(Date promoValidity) {
		this.promoValidity = promoValidity;
	}
	
	
}
