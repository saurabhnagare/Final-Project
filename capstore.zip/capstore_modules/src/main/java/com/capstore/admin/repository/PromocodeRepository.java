package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.capstore.admin.dto.PromoDTO;

public interface PromocodeRepository extends JpaRepository<PromoDTO, String> {

}
