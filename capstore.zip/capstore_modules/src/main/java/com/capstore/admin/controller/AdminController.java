package com.capstore.admin.controller;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.PromoDTO;
import com.capstore.admin.repository.PromocodeRepository;

@RestController
@RequestMapping("api/v1/")
public class AdminController {

	@Autowired
	private PromocodeRepository promocodeRepository;
	
	 @Autowired
	    private JavaMailSender sender;

	    @RequestMapping("sendMail")
	    public String sendMail() {
	        MimeMessage message = sender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);

	        try {
	            helper.setTo("rb72340@gmail.com");
	            helper.setText("Greetings :)");
	            helper.setSubject("Mail From Spring Boot");
	        } catch (MessagingException e) {
	            e.printStackTrace();
	            return "Error while sending mail ..";
	        }
	        sender.send(message);
	        return "Mail Sent Success!";
	    }
	

	@RequestMapping(value = "view_promocodes", method = RequestMethod.GET)
	public List<PromoDTO> list() {
		return promocodeRepository.findAll();
	}

	@RequestMapping(value = "promocodes", method = RequestMethod.POST)
	public PromoDTO create(@RequestBody PromoDTO PromoDTO) {
		return promocodeRepository.saveAndFlush(PromoDTO);
	}
}
