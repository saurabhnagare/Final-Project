package com.capstore.admin.dto;

import java.io.Serializable;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ReturnRequestKey implements Serializable 
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name="returnstatus") 
	private String returnstatus;
	@Column(name="refundamount") 
	private int refundamount;
	/*@Column(name="orderid") 
	private int order;*/
	@JsonIgnore
	public String getReturnstatus() {
		return returnstatus;
	}
	public void setReturnstatus(String returnstatus) {
		this.returnstatus = returnstatus;
	}
	@JsonIgnore
	public int getRefundamount() {
		return refundamount;
	}
	public void setRefundamount(int refundamount) {
		this.refundamount = refundamount;
	}
	
	
	}