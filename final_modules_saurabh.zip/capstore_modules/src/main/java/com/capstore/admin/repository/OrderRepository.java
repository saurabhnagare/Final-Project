package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.dto.OrderDTO;

public interface OrderRepository extends JpaRepository<OrderDTO, Integer>{

}
