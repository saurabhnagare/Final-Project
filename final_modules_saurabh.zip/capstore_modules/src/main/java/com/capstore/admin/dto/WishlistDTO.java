package com.capstore.admin.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="wishlist")
public class WishlistDTO {
 
	@OneToOne(targetEntity=ProductDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name = "productid",insertable = false, updatable = false)
	private ProductDTO product;
	
	@Id
	private int productprice;
	
	public ProductDTO getproduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public int getProductPrice() {
		return productprice;
	}
	public void setProductPrice(int productPrice) {
		this.productprice = productPrice;
	}
	
}
