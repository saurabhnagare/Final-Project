package com.capstore.admin.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="promo")
public class PromoDTO {

	@Id
	@Column(name="promocode")
	private String promoCode;
	
	@Column(name="discountoffered")
	private int discountoffered;
	
	@Column(name="promovalidity")
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date promovalidity;
	
	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public int getDiscountoffered() {
		return discountoffered;
	}

	public void setDiscountoffered(int discountoffered) {
		this.discountoffered = discountoffered;
	}

	public Date getPromovalidity() {
		return promovalidity;
	}

	public void setPromovalidity(Date promovalidity) {
		this.promovalidity = promovalidity;
	}

	public String getSoftdelete() {
		return softdelete;
	}

	public void setSoftdelete(String softdelete) {
		this.softdelete = softdelete;
	}

	@Column(name="softdelete")
	private String softdelete;
		
	
}
