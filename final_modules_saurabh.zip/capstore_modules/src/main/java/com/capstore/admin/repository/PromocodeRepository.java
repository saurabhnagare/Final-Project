package com.capstore.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capstore.admin.dto.PromoDTO;



public interface PromocodeRepository extends JpaRepository<PromoDTO, String> {
	 @Query(value = "SELECT * FROM PROMO WHERE SOFTDELETE = ?", nativeQuery = true)
	   List<PromoDTO> findactivepromo(@Param("softdelete")String softdelete);

}
