package com.capstore.admin.controller;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.MerchantDTO;
import com.capstore.admin.dto.OfferDTO;
import com.capstore.admin.dto.PromoDTO;
import com.capstore.admin.repository.MerchantRepository;
import com.capstore.admin.repository.OfferRepository;

@RestController
@RequestMapping("api/v1/")
public class MerchantController {
	
	@Autowired
	private OfferRepository offerRepository;
	
	
	
	@RequestMapping(value = "view_offers", method = RequestMethod.GET)
	public List<OfferDTO> list() {
		return offerRepository.findAll();
	}
	
	@RequestMapping(value = "view_offers/active", method = RequestMethod.GET)
	public List<PromoDTO> viewactive(String softdelete) {
		return offerRepository.findactiveoffer("A");
	}

	
	
	
	/*@RequestMapping(value = "merchants", method = RequestMethod.POST)
	public MerchantDTO create(@RequestBody MerchantDTO MerchantDTO) {
		return merchantRepository.saveAndFlush(MerchantDTO);
	}

	@RequestMapping(value = "merchants/{id}", method = RequestMethod.GET)
	public MerchantDTO get(@PathVariable Integer id) {
		return merchantRepository.findOne(id);
	}

	@RequestMapping(value = "merchants/{id}", method = RequestMethod.PUT)
	public MerchantDTO update(@PathVariable Integer id, @RequestBody MerchantDTO MerchantDTO) {
		MerchantDTO existingMerchant = merchantRepository.findOne(id);
		BeanUtils.copyProperties(MerchantDTO, existingMerchant);
		return merchantRepository.saveAndFlush(existingMerchant);
	}

	@RequestMapping(value = "merchants/{id}", method = RequestMethod.DELETE)
	public MerchantDTO delete(@PathVariable Integer id) {
		MerchantDTO existingMerchant = merchantRepository.findOne(id);
		merchantRepository.delete(existingMerchant);
		return existingMerchant;
	}
}*/
}
