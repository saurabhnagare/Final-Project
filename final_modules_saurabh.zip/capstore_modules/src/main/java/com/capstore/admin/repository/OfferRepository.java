package com.capstore.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capstore.admin.dto.OfferDTO;
import com.capstore.admin.dto.PromoDTO;

public interface OfferRepository  extends JpaRepository<OfferDTO, String>{
	 @Query(value = "SELECT * FROM OFFER WHERE SOFTDELETE = ?", nativeQuery = true)
	   List<PromoDTO> findactiveoffer(@Param("softdelete")String softdelete);

}
