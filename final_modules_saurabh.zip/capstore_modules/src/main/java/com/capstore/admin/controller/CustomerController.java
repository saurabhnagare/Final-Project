package com.capstore.admin.controller;

import java.util.List;

//import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.CustomerDTO;
import com.capstore.admin.dto.OrderDTO;
import com.capstore.admin.dto.PromoDTO;
import com.capstore.admin.dto.ReturnRequestDTO;
import com.capstore.admin.repository.CustomerRepository;
import com.capstore.admin.repository.OrderRepository;
import com.capstore.admin.repository.PromocodeRepository;
import com.capstore.admin.repository.ReturnRepository;

@RestController
@RequestMapping("api/v1/")
public class CustomerController {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private ReturnRepository returnRepository;

	@RequestMapping(value = "view_orders", method = RequestMethod.GET)
	public List<OrderDTO> list() {
		return orderRepository.findAll();
	}

	@RequestMapping(value = "view_orders/{id}", method = RequestMethod.GET)
	public OrderDTO create(@RequestBody OrderDTO OrderDTO) {
		return orderRepository.saveAndFlush(OrderDTO);
	}

	@RequestMapping(value = "view_orders/return", method = RequestMethod.POST)
	public ReturnRequestDTO addtoreturn(@RequestBody ReturnRequestDTO returnrequestDTO) {
		return returnRepository.saveAndFlush(returnrequestDTO);
	}
	
	@RequestMapping(value = "view_orders/return/{id}", method = RequestMethod.POST)
	public ReturnRequestDTO returnproduct(@RequestBody ReturnRequestDTO returnrequestDTO) {
		return returnRepository.saveAndFlush(returnrequestDTO);
	}
	
	
	
	
/*	@RequestMapping(value = "customers/{id}", method = RequestMethod.GET)
	public CustomerDTO get(@PathVariable Integer id) {
	//	return customerRepository.findOne(id);
	}*/

/*	@RequestMapping(value = "customers/{id}", method = RequestMethod.PUT)
	public CustomerDTO update(@PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		BeanUtils.copyProperties(customerDTO, existingCustomer);
		return customerRepository.saveAndFlush(existingCustomer);
	}

	@RequestMapping(value = "customers/{id}", method = RequestMethod.DELETE)
	public CustomerDTO delete(@PathVariable Integer id) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		customerRepository.delete(existingCustomer);
		return existingCustomer;
	}*/

}
