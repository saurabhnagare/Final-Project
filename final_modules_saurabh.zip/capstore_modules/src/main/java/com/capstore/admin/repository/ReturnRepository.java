package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.capstore.admin.dto.ReturnRequestDTO;

public interface ReturnRepository extends JpaRepository<ReturnRequestDTO, Integer> {

}
